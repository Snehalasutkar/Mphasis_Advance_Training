package com.net.springboot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.net.springboot.entity.Product;

public interface ProductDAO extends JpaRepository<Product,Long>{
public void addProduct(Product product);
public void findProductbyId(long id);
public void deleteProductbyId(long id);
public void updateProductbyId(long id);

public List<Product> allProduct();

public void findByCategory(String name);

public void brandAndModel(String BrandAndModel);

public void brandOrModel(String BrandOrModel);

public void brandOrModelorCategory(String BrandOrModelorCategory);



}

 
